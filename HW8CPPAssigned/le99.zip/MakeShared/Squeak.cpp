#include <iostream>
#include "Squeak.h"

void Squeak::quack( ) {
   std::cout << "Squeak!" << std::endl;
}
