#include <iostream>
#include "MuteQuack.h"

void MuteQuack::quack( ) {
   std::cout << ". . ." << std::endl;
}
