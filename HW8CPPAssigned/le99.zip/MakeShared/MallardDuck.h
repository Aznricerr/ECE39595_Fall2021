#ifndef MALLARDDUCK_H_
#define MALLARDDUCK_H_
#include "Duck.h"
#include <memory>

class MallardDuck : public Duck
{
public:
   MallardDuck();
   void display();
};
#endif /* MALLARDDUCK_H_ */
