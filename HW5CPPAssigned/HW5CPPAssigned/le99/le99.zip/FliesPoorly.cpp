#include <iostream>
#include "FliesPoorly.h"

void FliesPoorly::fly()
{
    std::cout << "flies poorly" << std::endl;
}