#include <iostream>
#include "LaysEggsNotBroody.h"

void LaysEggsNotBroody::laysEgg()
{
    std::cout << "Lays eggs and will give them up if fed." << std::endl;
}