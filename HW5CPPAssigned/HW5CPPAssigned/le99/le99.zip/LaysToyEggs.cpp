#include <iostream>
#include "LaysToyEggs.h"

void LaysToyEggs::laysEgg()
{
    std::cout << "Lays toy eggs." << std::endl;
}