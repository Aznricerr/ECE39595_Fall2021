#include <iostream>
#include "LaysEggsBroody.h"

void LaysEggsBroody::laysEgg()
{
    std::cout << "Lays eggs, but will fight you for them." << std::endl;
}