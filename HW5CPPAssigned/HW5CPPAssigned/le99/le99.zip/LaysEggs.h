#ifndef LAYSEGGS_H_
#define LAYSEGGS_H_

class LaysEggs
{
public:
    virtual void laysEgg() = 0;
};
#endif