#ifndef PEKINDUCK_H_
#define PEKINDUCK_H_
#include "Duck.h"

class PekinDuck : public Duck
{
public:
    PekinDuck();
    void display();
};
#endif