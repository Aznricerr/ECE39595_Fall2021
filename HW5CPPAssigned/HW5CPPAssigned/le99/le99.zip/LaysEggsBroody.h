#ifndef LAYSEGGSBROODY_H_
#define LAYSEGGSBROODY_H_
#include "LaysEggs.h"

class LaysEggsBroody : public LaysEggs
{
public:
    void laysEgg();
};
#endif